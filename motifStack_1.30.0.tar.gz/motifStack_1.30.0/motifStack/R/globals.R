# a scope where we can put mutable global state
.globals <- new.env(parent = emptyenv())
