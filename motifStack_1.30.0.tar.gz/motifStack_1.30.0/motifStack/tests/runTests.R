require("motifStack") || stop("unable to load Package:motifStack")
#require("MotifDb") || stop("unalble to load Package::motifDb")
BiocGenerics:::testPackage("motifStack")